import { Component, OnInit, OnDestroy } from '@angular/core';
import { CommonModule } from '@angular/common';
import {
  BookCardComponent,
  Book,
} from '../../components/shared/book-card/book-card.component';
import { BookService } from '../../services/book.service';
import { Subscription, map } from 'rxjs';

@Component({
  selector: 'app-daftar-buku',
  imports: [CommonModule, BookCardComponent],
  templateUrl: './daftar-buku.component.html',
  styleUrl: './daftar-buku.component.scss',
  standalone: true,
})
export class DaftarBukuComponent implements OnInit, OnDestroy {
  private subscriptions = new Subscription();
  allBooksMasterList: Book[] = [];
  filteredBooks: Book[] = [];
  displayCategories: string[] = [];
  selectedCategories: Set<string> = new Set();
  readonly ALL_CATEGORY = 'Semua';

  constructor(private bookService: BookService) {}

  ngOnInit(): void {
    this.subscriptions.add(
      this.bookService.getAllBooks().subscribe((books) => {
        this.allBooksMasterList = books;
        this.applyFilters();
      })
    );
    this.subscriptions.add(
      this.bookService.getUniqueCategories().subscribe((cats) => {
        this.displayCategories = [this.ALL_CATEGORY, ...cats];
      })
    );
  }

  handleFavoriteToggled(bookId: string | number): void {
    this.bookService.toggleFavorite(bookId);
  }

  toggleCategory(category: string): void {
    if (category === this.ALL_CATEGORY) {
      this.selectedCategories.clear();
    } else {
      if (this.selectedCategories.has(category)) {
        this.selectedCategories.delete(category);
      } else {
        this.selectedCategories.add(category);
      }
    }
    this.applyFilters();
  }

  isCategoryActive(category: string): boolean {
    if (category === this.ALL_CATEGORY) {
      return this.selectedCategories.size === 0;
    }
    return this.selectedCategories.has(category);
  }

  applyFilters(): void {
    let tempFiltered: Book[];
    if (this.selectedCategories.size === 0) {
      tempFiltered = [...this.allBooksMasterList];
    } else {
      tempFiltered = this.allBooksMasterList.filter((book) =>
        (book.categories || []).some((cat) => this.selectedCategories.has(cat))
      );
    }
    this.filteredBooks = tempFiltered.sort((a, b) =>
      a.title.localeCompare(b.title)
    );
  }

  ngOnDestroy(): void {
    this.subscriptions.unsubscribe();
  }
}

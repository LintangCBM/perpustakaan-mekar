import { Component, OnInit, OnDestroy } from '@angular/core';
import { CommonModule } from '@angular/common';
import {
  BookCardComponent,
  Book,
} from '../../components/shared/book-card/book-card.component';
import { BookService } from '../../services/book.service';
import { Subscription } from 'rxjs';
import { tap } from 'rxjs/operators';

@Component({
  selector: 'app-favorit',
  imports: [CommonModule, BookCardComponent],
  templateUrl: './favorit.component.html',
  styleUrl: './favorit.component.scss',
  standalone: true,
})
export class FavoritComponent implements OnInit, OnDestroy {
  private subscriptions = new Subscription();
  allFavoriteBooks: Book[] = [];
  filteredFavoriteBooks: Book[] = [];
  displayCategories: string[] = [];
  selectedCategories: Set<string> = new Set();
  readonly ALL_CATEGORY = 'Semua';

  constructor(private bookService: BookService) {}

  ngOnInit(): void {
    this.subscriptions.add(
      this.bookService
        .getFavoriteBooks()
        .pipe(
          tap((favBooks) => {
            this.allFavoriteBooks = favBooks;
            this.extractUniqueCategoriesFromFavorites();
            this.applyCategoryFilters();
          })
        )
        .subscribe()
    );
  }

  extractUniqueCategoriesFromFavorites(): void {
    if (!this.allFavoriteBooks || this.allFavoriteBooks.length === 0) {
      this.displayCategories = [this.ALL_CATEGORY];
      return;
    }
    const favoriteCats = new Set<string>();
    this.allFavoriteBooks.forEach((book) => {
      (book.categories || []).forEach((cat) => favoriteCats.add(cat));
    });
    this.displayCategories = [
      this.ALL_CATEGORY,
      ...Array.from(favoriteCats).sort(),
    ];
    const currentDisplayCatSet = new Set(this.displayCategories);
    this.selectedCategories.forEach((selectedCat) => {
      if (
        selectedCat !== this.ALL_CATEGORY &&
        !currentDisplayCatSet.has(selectedCat)
      ) {
        this.selectedCategories.delete(selectedCat);
      }
    });
  }

  handleFavoriteToggled(bookId: string | number): void {
    this.bookService.toggleFavorite(bookId);
  }

  toggleCategory(category: string): void {
    if (category === this.ALL_CATEGORY) {
      this.selectedCategories.clear();
    } else {
      if (this.selectedCategories.has(category)) {
        this.selectedCategories.delete(category);
      } else {
        this.selectedCategories.add(category);
      }
    }
    this.applyCategoryFilters();
  }

  isCategoryActive(category: string): boolean {
    if (category === this.ALL_CATEGORY) {
      return this.selectedCategories.size === 0;
    }
    return this.selectedCategories.has(category);
  }

  applyCategoryFilters(): void {
    let tempFiltered: Book[];
    if (this.selectedCategories.size === 0) {
      tempFiltered = [...this.allFavoriteBooks];
    } else {
      tempFiltered = this.allFavoriteBooks.filter((book) =>
        (book.categories || []).some((cat) => this.selectedCategories.has(cat))
      );
    }
    this.filteredFavoriteBooks = tempFiltered.sort((a, b) =>
      a.title.localeCompare(b.title)
    );
  }

  ngOnDestroy(): void {
    this.subscriptions.unsubscribe();
  }
}
